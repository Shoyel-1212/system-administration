#!/bin/bash
# Task 2: Old File Archiver (user-mode)

SOURCE="$HOME"
ARCHIVE="$HOME/archive"
mkdir -p "$ARCHIVE"

TS=$(date '+%Y-%m-%d %H:%M:%S')
find "$SOURCE" -type f -mtime +30 -exec mv {} "$ARCHIVE" \;

echo "[$TS] Files older than 30 days moved to $ARCHIVE"

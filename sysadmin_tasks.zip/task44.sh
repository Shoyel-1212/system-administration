#!/bin/bash
# Task 44: System Boot History Summary

LOGDIR="$HOME/logs"
LOGFILE="$LOGDIR/boot_history.log"
mkdir -p "$LOGDIR"

TS=$(date '+%Y-%m-%d %H:%M:%S')

{
  echo "=============================================="
  echo "System Boot History Summary - $TS"
  echo "=============================================="
  last reboot | head -20
  echo ""
} >> "$LOGFILE"

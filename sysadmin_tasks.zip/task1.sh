#!/bin/bash
# Task 1: Disk Space Alert System (Root version)

THRESHOLD=${1:-80}
LOGFILE="/var/log/disk_alert.log"
MAIL_TO="admin@mycomp.com"

USAGE=$(df -P / | awk 'NR==2{print $5}' | tr -d '%')
HOST=$(hostname)
TS=$(date '+%Y-%m-%d %H:%M:%S')

if [ "$USAGE" -ge "$THRESHOLD" ]; then
  MESSAGE="[$TS] ALERT: Root partition usage is ${USAGE}% (Threshold: ${THRESHOLD}%) on ${HOST}"
  echo "$MESSAGE" | tee -a "$LOGFILE"
else
  echo "[$TS] OK: Root usage ${USAGE}% (Threshold: ${THRESHOLD}%)" >> "$LOGFILE"
fi

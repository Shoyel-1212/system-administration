#!/bin/bash
# Task 5: Zombie Process Detector

LOGDIR="$HOME/logs"
LOGFILE="$LOGDIR/zombie_processes.log"
mkdir -p "$LOGDIR"

TS=$(date '+%Y-%m-%d %H:%M:%S')

{
  echo "=============================================="
  echo "Zombie Process Check - $TS"
  echo "=============================================="
  ps aux | awk '{ if ($8=="Z") print $0 }'
  echo ""
} >> "$LOGFILE"

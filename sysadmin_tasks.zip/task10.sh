#!/bin/bash
# Task 10: User Session Logger

LOGDIR="$HOME/logs"
LOGFILE="$LOGDIR/user_sessions.log"
mkdir -p "$LOGDIR"

TS=$(date '+%Y-%m-%d %H:%M:%S')

{
  echo "=============================================="
  echo "User Session Log - $TS"
  echo "=============================================="
  who
  echo ""
} >> "$LOGFILE"
